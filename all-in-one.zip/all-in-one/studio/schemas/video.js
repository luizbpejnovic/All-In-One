export default {
  name: 'video',
  title: 'Video',
  type: 'document',
  fields: [
    { name: 'title', title: 'Title', type: 'string' },
    { name: 'slug', title: 'Slug', type: 'slug', options: { source: 'title' } },
    { name: 'videoUrl', title: 'Video URL (embed)', type: 'url' },
    { name: 'description', title: 'Description', type: 'text' },
    { name: 'creator', title: 'Creator', type: 'reference', to: [{ type: 'creator' }] },
    { name: 'publishedAt', title: 'Published at', type: 'datetime' }
  ]
}
