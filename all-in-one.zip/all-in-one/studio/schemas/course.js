export default {
  name: 'course',
  title: 'Course',
  type: 'document',
  fields: [
    { name: 'title', title: 'Title', type: 'string' },
    { name: 'slug', title: 'Slug', type: 'slug', options: { source: 'title' } },
    { name: 'summary', title: 'Summary', type: 'text' },
    { name: 'hours', title: 'Hours', type: 'number' },
    { name: 'level', title: 'Level', type: 'string' },
    { name: 'instructor', title: 'Instructor', type: 'reference', to: [{ type: 'creator' }] },
    { name: 'coverImage', title: 'Cover Image', type: 'image' },
    { name: 'publishedAt', title: 'Published at', type: 'datetime' }
  ]
}
