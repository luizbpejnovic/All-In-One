// Simple assistant proxy. Requires OPENAI_API_KEY set in env.
import axios from 'axios'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { messages } = req.body
  if (!process.env.OPENAI_API_KEY) {
    return res.status(500).json({ error: 'OPENAI_API_KEY not configured' })
  }
  try {
    const resp = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: 'gpt-4o-mini', // change as needed
      messages,
      max_tokens: 800
    }, {
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      }
    })
    return res.status(200).json(resp.data)
  } catch (err) {
    console.error(err.response?.data || err.message)
    return res.status(500).json({ error: 'assistant error' })
  }
}
