import { getServerSession } from 'next-auth/next'
import { authOptions } from '../auth/[...nextauth]'
import { sanityClient } from '../../../lib/sanity'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const session = await getServerSession(req, res, authOptions)
  if (!session || !['admin','creator'].includes(session.user.role)) {
    return res.status(403).json({ error: 'Forbidden' })
  }
  const { title, summary, hours, level, instructorId } = req.body
  try {
    const doc = {
      _type: 'course',
      title,
      summary,
      hours,
      level,
      instructor: { _type: 'reference', _ref: instructorId },
      publishedAt: new Date().toISOString()
    }
    const created = await sanityClient.create(doc)
    return res.status(201).json({ ok: true, id: created._id })
  } catch (err) {
    console.error(err)
    return res.status(500).json({ error: 'Erro ao criar curso' })
  }
}
