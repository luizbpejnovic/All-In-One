import React, { useState } from 'react'

export default function AssistantPage() {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)

  async function send() {
    if (!input) return
    const newMsg = { role: 'user', content: input }
    const next = [...messages, newMsg]
    setMessages(next)
    setInput('')
    setLoading(true)
    try {
      const r = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next })
      })
      const data = await r.json()
      const reply = data.choices?.[0]?.message || { content: 'Sem resposta' }
      setMessages(prev => [...prev, { role: 'assistant', content: reply.content }])
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Erro no servidor' }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen p-8">
      <h1 className="text-2xl font-bold mb-4">Assistente All In One</h1>
      <div className="border rounded-md p-4 mb-4 max-w-2xl">
        {messages.map((m, i) => (
          <div key={i} className={`mb-3 ${m.role==='assistant' ? 'text-slate-700' : 'text-black'}`}>
            <strong>{m.role}:</strong> <span>{m.content}</span>
          </div>
        ))}
        <div className="flex gap-2">
          <input value={input} onChange={e=>setInput(e.target.value)} className="flex-1 px-3 py-2 border rounded-md" />
          <button onClick={send} className="px-4 py-2 bg-black text-white rounded-md" disabled={loading}>Enviar</button>
        </div>
      </div>
    </main>
  )
}
