import React from 'react'
import Link from 'next/link'

export default function Home() {
  return (
    <main className="min-h-screen p-8 bg-white text-slate-900">
      <header className="flex justify-between items-center mb-10">
        <h1 className="text-3xl font-bold">All In One</h1>
        <nav className="flex gap-6 text-lg">
          <Link href="#courses">Cursos</Link>
          <Link href="#videos">Vídeos</Link>
          <Link href="#music">Música</Link>
          <Link href="/assistant">Assistente</Link>
        </nav>
      </header>

      <section className="text-center mb-16">
        <h2 className="text-5xl font-bold mb-4">Tudo em um só lugar</h2>
        <p className="text-xl text-gray-600 mb-6">Cursos, vídeos, filmes, música e rede social — integrados em uma única plataforma.</p>
      </section>

      <section id="courses" className="mb-12">
        <h3 className="text-3xl font-bold mb-4">Cursos</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="p-6 border rounded-2xl shadow-sm">
            <h4 className="text-2xl font-semibold">Programação</h4>
            <p className="text-gray-600">Aprenda do zero até avançado.</p>
          </div>
          <div className="p-6 border rounded-2xl shadow-sm">
            <h4 className="text-2xl font-semibold">Design</h4>
            <p className="text-gray-600">Design minimalista e UX.</p>
          </div>
          <div className="p-6 border rounded-2xl shadow-sm">
            <h4 className="text-2xl font-semibold">Música</h4>
            <p className="text-gray-600">Violão, produção musical e mais.</p>
          </div>
        </div>
      </section>

      <section id="videos" className="mb-12">
        <h3 className="text-3xl font-bold mb-4">Vídeos</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-gray-100 p-6 rounded-2xl">Aula introdutória</div>
          <div className="bg-gray-100 p-6 rounded-2xl">Live: Roadmap</div>
          <div className="bg-gray-100 p-6 rounded-2xl">Trailer dos cursos</div>
        </div>
      </section>

      <section id="music" className="mb-12">
        <h3 className="text-3xl font-bold mb-4">Música</h3>
        <div className="bg-gray-900 text-white p-8 rounded-2xl">Player (mock)</div>
      </section>

      <footer className="mt-16 text-sm text-slate-500">© All In One</footer>
    </main>
  )
}
